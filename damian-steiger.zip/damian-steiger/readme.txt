
Assignment #1 | Damian Steiger | 216433476

a) YES
	using real time, with JavaScript Date function, to synchronize animation

b) YES
	ground box exists

c) YES
	2 rocks are present

d) YES
	each seaweed strand has 10 ellipses

e) YES
	each subsequent piece of seaweed is rotated within the previous piece's rotation frame, meaning no gaps formed between pieces, single point rotation

f) YES
	seaweed is on top of the rocks, each strand moving identically

g) YES
	fish model is accurate
 
h) YES
	fish rotates it's normal tangent to a line in the middle of the larger rock (translation, rotation, translation)

i) YES
	random number generator decides between 4 and 5 bubbles every few seconds

j) YES
	the bubble's location is relative to the movement of the head

k) YES
	bubbles oscillate by scaling their x and y with cos or sin function

l) YES
	bubble has y position with respect to time, goes straight up

m) YES
	bubbles are deleted after ~ 12 seconds by monitoring TIME

n) YES
	modelled character with a sphere, a cube, two scaled cubes for thighs, two scaled cubes for shins, and two scaled cubes for feet

o) YES
	character does a x and y position osculation with cos function and time units

p) YES
	The things kick by rotating in the world coordinates, and the shins rotate within the thighs coordinates (correct point rotation). The feet rotate within the thigh coordinates, but do not move relative to the shins.

q) YES
	It looks very similar

r) YES
	Each function (randomBubble, buuble2, bubble, rock, and seaweed, seaweedHelper),  is titled with descriptions, transformations are marked with their purpose, objects are marked, follows proper JS naming conventions (ex. randomBubble)

s) YES
	the screen is 512 x 512

t) YES
	the name of the submitted file is damian-steiger.zip

u) YES
	Read me is included

